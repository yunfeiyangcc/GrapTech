#include <windows.h>
#include <stdlib.h>
#include <stdio.h>
//we use opengl
#include <GL/freeglut.h>

//comment opengl lib
#pragma comment(lib,"opengl32.lib")
#pragma comment(lib,"glu32.lib")
#pragma comment(lib,"freeglut.lib")

//function forward decl
void init(void);
void display(void);
void reshape(int w,int h);
void keyboard(unsigned char key,int x,int y);

//some global var
static int shoulder = 0,elbow = 0,hand = 0;

//our main function
int main(int argc,char** argv)
{
	//init glut
	glutInit(&argc,argv);

	//create window using glut function
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize(1000,1000);
	glutInitWindowPosition(100,100);
	glutCreateWindow("robot arm");
	printf("s��S��---Shoulder��ת\n");
	printf("e��E��---Elbow��ת\n");
	printf("h��H��------Hand��ת\n");
	
	//init opengl
	init();

	//register callback function
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutKeyboardFunc(keyboard);

	//loop!!
	glutMainLoop();

	//return from our program
	return 0;
}

//init opengl
void init(void)
{
	//clear color
	glClearColor(0.0f,0.0f,0.0f,0.0f);
	glShadeModel(GL_FLAT);
}

//our draw callback function
void display(void)
{
	//clear buffer bit
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	//we use push matrix to save our current matrix stack top
	glPushMatrix();

	//draw shoulder
	glRotatef((GLfloat)shoulder,0.0f,0.0f,1.0f);
	glTranslatef(1.0f,0.0f,0.0f);		//Ϊ���ƶ�1.0?
	glPushMatrix();
		glScalef(2.0f,0.4f,1.0f);
		glutWireCube(1.0);
	glPopMatrix();

	//draw elbow
	glTranslatef(1.0f,0.0f,0.0f);	//Ϊ��Ҫ��ô�ƶ���Ϊ���ƶ�1.0
	glRotatef((GLfloat)elbow,0.0f,0.0f,1.0f);
	glTranslatef(1.0f,0.0f,0.0f);
	glPushMatrix();
		glScalef(2.0f,0.4,1.0f);
		glutWireCube(1.0);
	glPopMatrix();

	//draw hand
	glTranslatef(1.25f,0.0f,0.0f);		//Ϊ��Ҫ��ô�ƶ���Ϊ���ƶ�1.0
	glRotatef((GLfloat)hand,1.0f,0.0f,0.0f);
	glPushMatrix();
		glTranslatef(0.0f,0.2f,0.0f);
		glScalef(1.0f,0.2f,0.5f);
		glutWireCube(0.5);
	glPopMatrix();
	glPushMatrix();
	glTranslatef(0.0f,-0.2f,0.0f);
	glScalef(1.0f,0.2f,0.5f);
	glutWireCube(0.5);
	glPopMatrix();

	//we recover our matrix stack using pop matrix
	glPopMatrix();

	//swap buffers to show our draw above
	glutSwapBuffers();
}

//our reshape callback function
void reshape(int w,int h)
{
	//set viewport
	glViewport(0,0,(GLsizei)w,(GLsizei)h);
	//set projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(65.0,(GLfloat)w/(GLfloat)h,1.0,20.0);
	//change to modelview matrix to prepare for draw our scene
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	//use glTranslate to make we can see the scene
	//we can change this by using gluLookAt function becase we know
	//they are relatively
	glTranslatef(0.0f,0.0f,-5.0f);
}

//our keyboard callback function
void keyboard(unsigned char key,int x,int y)
{
	//we do somting by diffrent key
	//we should call glutPostRedisplay function to tell our program to redraw our scene
	switch(key)
	{
	case 's':
		{
			shoulder = (shoulder + 5) % 360;
			glutPostRedisplay();
		}
		break;
	case 'S':
		{
			shoulder = (shoulder - 5) % 360;
			glutPostRedisplay();
		}
		break;
	case 'e':
		{
			elbow = (elbow + 5) % 360;
			glutPostRedisplay();
		}
		break;
	case 'E':
		{
			elbow = (elbow - 5) % 360;
			glutPostRedisplay();
		}
		break;
	case 'h':
		{
			hand = (hand + 5) % 360;
			glutPostRedisplay();
		}
		break;
	case 'H':
		{
			hand = (hand - 5) % 360;
			glutPostRedisplay();
		}
		break;
	}
}